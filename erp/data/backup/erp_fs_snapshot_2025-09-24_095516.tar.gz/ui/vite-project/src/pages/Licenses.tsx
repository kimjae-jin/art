import PageSplit from "../components/PageSplit";
export default function Licenses(){
  const Top = (<div className="tag">면허 요약(법적 기준 충족도 등)</div>);
  const Bottom = (<div className="tag">면허 세부(인원/장비/자본금 기준표 + 링크)</div>);
  return <PageSplit top={Top} bottom={Bottom}/>;
}
