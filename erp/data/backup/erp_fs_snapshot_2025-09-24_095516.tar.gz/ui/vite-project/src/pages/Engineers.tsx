import React, { useEffect, useMemo, useState } from "react";
import { apiGet, apiPost } from "../lib/api"; // 기존 프로젝트에 맞게 수정됨
import { getTheme, setTheme } from "../theme";

/** 간단한 상태 칩 컴포넌트 */
function StatusChip({ status }: { status: string }) {
  const cls =
    status === "재직" ? "chip working" :
    status === "퇴사예정" ? "chip plan" :
    status === "퇴직" ? "chip retired" : "chip";
  return <span className={cls}>{status}</span>;
}

type EngineerRow = {
  id: number;
  engineer_code?: string;
  employee_no?: string;
  name?: string;
  status?: string;
  joined_at?: string | null;
  retired_at?: string | null;
  birth?: string | null;
  address?: string | null;
  phone?: string | null;
  dept?: string | null;
  resign_expected_at?: string | null;
  note?: string | null;
};

export default function Engineers() {
  const [items, setItems] = useState<EngineerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [limit] = useState(5000);
  const [offset] = useState(0);
  const [theme, setThemeState] = useState(getTheme());

  useEffect(() => {
    setThemeState(getTheme());
  }, []);

  useEffect(() => {
    loadList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadList() {
    setLoading(true);
    try {
      const res = await apiGet("/engineers", { limit, offset });
      // expect { items: [...] }
      if (res?.items) setItems(res.items);
    } catch (err) {
      console.error("loadList error:", err);
    } finally {
      setLoading(false);
    }
  }

  const filtered = useMemo(() => {
    if (!query) return items;
    const q = query.trim().toLowerCase();
    return items.filter((r) =>
      (r.employee_no || "").toLowerCase().includes(q) ||
      (r.name || "").toLowerCase().includes(q) ||
      (r.dept || "").toLowerCase().includes(q) ||
      (r.address || "").toLowerCase().includes(q) ||
      (r.phone || "").toLowerCase().includes(q)
    );
  }, [items, query]);

  const allChecked = filtered.length > 0 && filtered.every((r) => selectedIds.includes(r.id));

  function toggleSelectOne(id: number) {
    setSelectedIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  }

  function toggleSelectAll() {
    if (allChecked) {
      // uncheck visible
      setSelectedIds((prev) => prev.filter((id) => !filtered.some((r) => r.id === id)));
    } else {
      // add visible
      setSelectedIds((prev) => {
        const ids = new Set(prev);
        filtered.forEach((r) => ids.add(r.id));
        return Array.from(ids);
      });
    }
  }

  async function onBulkDelete() {
    if (!selectedIds.length) return alert("삭제할 항목을 선택하세요.");
    if (!confirm(`선택한 ${selectedIds.length}건을 삭제하시겠습니까?`)) return;
    try {
      const resp = await apiPost("/engineers/bulk-delete", { ids: selectedIds });
      // backend returns { deleted: n }
      if (resp?.deleted >= 0) {
        alert(`삭제 완료: ${resp.deleted} 건`);
        // 새로고침: 다시 불러오고 선택 비움
        setSelectedIds([]);
        await loadList();
      } else {
        alert("삭제 실패");
      }
    } catch (err) {
      console.error(err);
      alert("삭제 중 오류가 발생했습니다.");
    }
  }

  function onCreate() {
    // 이동 / 페이지 열기 로직(기존 경로 유지)
    window.location.href = "/engineers/new";
  }

  function onOpenImport() {
    // 기존 입력창 열기(implementation in your UI)
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.xlsx,.xls";
    input.onchange = async (ev: any) => {
      const file = ev.target.files?.[0];
      if (!file) return;
      // fallback: send to server or process client-side
      const fd = new FormData();
      fd.append("file", file);
      try {
        const res = await fetch("/engineers/import", { method: "POST", body: fd });
        if (!res.ok) throw new Error(await res.text());
        alert("불러오기 완료");
        loadList();
      } catch (e) {
        alert("불러오기 실패: " + (e as any).message);
      }
    };
    input.click();
  }

  function onExportCsv() {
    window.open("/engineers/export?format=csv", "_blank");
  }

  function reload() {
    loadList();
  }

  return (
    <main className="page">
      <div className="header" role="banner">
        <div className="brand" onClick={() => (window.location.href = "/")}>ERP</div>
        <nav className="nav">
          <a className="active">기술인</a>
          <a onClick={() => (window.location.href = "/projects")}>프로젝트</a>
          <a onClick={() => (window.location.href = "/licenses")}>면허</a>
        </nav>
        <div className="spacer" />
        <div className="badge">총 {items.length}건</div>
        <button
          className="theme-toggle"
          onClick={() => {
            const t = theme === "light" ? "dark" : "light";
            setTheme(t);
            setThemeState(t);
          }}
        >
          테마: {theme === "light" ? "라이트" : "다크"}
        </button>
      </div>

      <div style={{ padding: "12px 0" }}>
        <div className="toolbar">
          <div className="search">
            <input
              placeholder="검색: 사번/성명/부서/연락처/주소"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          <button className="btn btn-primary" onClick={onCreate}>신규 등록</button>
          <button className="btn" onClick={onOpenImport}>불러오기(CSV/XLSX)</button>
          <button className="btn" onClick={onExportCsv}>CSV 내보내기</button>
          <button className="btn btn-danger" disabled={!selectedIds.length} onClick={onBulkDelete}>선택삭제</button>
          <button className="btn" onClick={reload}>새로고침</button>
        </div>

        <table className="table" aria-hidden={loading}>
          <thead>
            <tr>
              <th style={{ width: 48 }}>
                <input
                  type="checkbox"
                  checked={allChecked}
                  onChange={toggleSelectAll}
                  aria-label="전체 선택"
                />
              </th>
              <th style={{ width: 90 }}>상태</th>
              <th style={{ width: 110 }}>사번</th>
              <th>성명</th>
              <th>생년월일</th>
              <th>입사일</th>
              <th>주소</th>
              <th>연락처</th>
              <th>부서</th>
              <th>퇴사예정일</th>
              <th>퇴사일</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={12} style={{ textAlign: "center", padding: 32 }}>데이터가 없습니다.</td></tr>
            ) : filtered.map((r) => (
              <tr key={r.id}>
                <td>
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(r.id)}
                    onChange={() => toggleSelectOne(r.id)}
                  />
                </td>
                <td><StatusChip status={r.status || "알수없음"} /></td>
                <td>{r.employee_no}</td>
                <td>
                  <a href={`/engineers/${r.id}`} style={{ color: "inherit", textDecoration: "none" }}>{r.name}</a>
                </td>
                <td>{r.birth ?? ""}</td>
                <td>{r.joined_at ?? ""}</td>
                <td>{r.address ?? ""}</td>
                <td>{r.phone ?? ""}</td>
                <td>{r.dept ?? ""}</td>
                <td>{r.resign_expected_at ?? ""}</td>
                <td>{r.retired_at ?? ""}</td>
                <td>{r.note ?? ""}</td>
              </tr>
            ))}
          </tbody>
        </table>

      </div>
    </main>
  );
}
