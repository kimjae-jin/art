from fastapi import APIRouter, Query
from sqlalchemy.sql import text
from app.db import SessionLocal

router = APIRouter(prefix="/engineers", tags=["engineers"])

@router.get("")
def list_engineers(limit: int = Query(5000, ge=1, le=10000), offset: int = 0):
    sql = text("""
        SELECT
          e.id,
          ''::text AS engineer_code,              -- UI 호환용
          e.employee_no,
          e.name,
          COALESCE(e.status, '') AS status,
          e.joined_at,
          e.retired_at,
          NULL::date  AS birth,                   -- 아직 DB에 없으므로 NULL alias
          NULL::text  AS address,
          NULL::text  AS phone,
          NULL::text  AS dept,
          NULL::date  AS resign_expected_at,
          NULL::text  AS note
        FROM engineers e
        ORDER BY e.id ASC
        LIMIT :limit OFFSET :offset
    """)
    with SessionLocal() as s:
        rows = s.execute(sql, {"limit": limit, "offset": offset}).mappings().all()
        return {"items": [dict(r) for r in rows]}

@router.post("/bulk-delete")
def bulk_delete(payload: dict):
    ids = payload.get("ids") or []
    if not isinstance(ids, list) or not all(isinstance(x, int) for x in ids) or not ids:
        return {"deleted": 0}
    sql = text("DELETE FROM engineers WHERE id = ANY(:ids)")
    with SessionLocal() as s:
        res = s.execute(sql, {"ids": ids})
        s.commit()
        return {"deleted": res.rowcount or 0}
