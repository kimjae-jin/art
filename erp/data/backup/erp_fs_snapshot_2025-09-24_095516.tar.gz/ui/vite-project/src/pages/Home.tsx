export default function Home(){ return <div className="page">홈</div>; }
