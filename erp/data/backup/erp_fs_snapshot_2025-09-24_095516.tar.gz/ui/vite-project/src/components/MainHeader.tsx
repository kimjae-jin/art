import React from "react";
import { getTheme, setTheme } from "../theme";

export default function MainHeader() {
  const theme = getTheme();
  return (
    <header className="header" role="banner">
      <div className="brand" onClick={() => (window.location.href = "/")}>ERP</div>
      <nav className="nav">
        <a className="active">기술인</a>
        <a onClick={() => (window.location.href = "/projects")}>프로젝트</a>
        <a onClick={() => (window.location.href = "/licenses")}>면허</a>
      </nav>
      <div className="spacer" />
      <div className="badge">준비 중</div>
      <button
        className="theme-toggle"
        onClick={() => {
          const t = theme === "light" ? "dark" : "light";
          setTheme(t);
        }}
      >
        테마: {theme === "light" ? "라이트" : "다크"}
      </button>
    </header>
  );
}
