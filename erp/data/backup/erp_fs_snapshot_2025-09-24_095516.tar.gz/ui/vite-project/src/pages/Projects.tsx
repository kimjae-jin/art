export default function Projects(){ return <div className="page">프로젝트 리스트(다음 단계에서 연동)</div>; }
