# backend/app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# 라우터 모듈들
# (프로젝트에 이미 존재하던 모듈명을 그대로 사용합니다)
from app.routers import engineers, projects, stub
from app.routers import engineer_careers  # ★ 추가: 기술경력 라우터

app = FastAPI(title="ERP Backend", version="1.0.0")

# CORS: Vite(프론트) 개발 주소 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 헬스체크
@app.get("/")
def read_root():
    return {"status": "ok"}

# 라우터 등록
app.include_router(engineers.router)
app.include_router(projects.router)
app.include_router(stub.router)
app.include_router(engineer_careers.router)  # ★ 추가 등록

# uvicorn 직접 실행 시
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )