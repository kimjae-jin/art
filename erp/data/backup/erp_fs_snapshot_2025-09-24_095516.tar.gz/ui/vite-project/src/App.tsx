import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainHeader from "./components/MainHeader";
import Engineers from "./pages/Engineers";
import Projects from "./pages/Projects";
import Licenses from "./pages/Licenses";

function Home() {
  return <div style={{padding:16}}>준비 중</div>;
}

export default function App() {
  return (
    <BrowserRouter>
      <MainHeader />
      <main className="page">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/engineers" element={<Engineers />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/licenses" element={<Licenses />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}
